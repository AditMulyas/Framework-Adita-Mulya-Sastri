<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Home</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>

		<div class="container">	
		<nav class="navbar navbar-default" role="navigation">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
				</div>
		
					<!-- <div class="btn-group btn-group-lg" role="group" aria-label="...">...</div> -->

						<ul class="nav nav-tabs">
							  <li role="presentation" class="active"><a href="#">Home</a></li>
							  <li role="presentation"><a href="#">Profile</a></li>
							  <li role="presentation"><a href="#">Messages</a></li>
						
						   <form class="navbar-form navbar-right" role="search">
						   <div class="form-group navbar-right">
										<input type="text" class="form-control" placeholder="Search">
									</div>
									<button type="submit" class="btn btn-default">Submit</button>
								</form>
							</ul>

				<div class="container">
					<center><h1>Hy, Saya Adita Mulya Sastri. </h1>
					<h4>Selamat datang di Blog Saya</h4>
					</center>
				</div>
			</div>

			<div class="jumbotron">
				<div class="container">
					<p>Berikut merupakan beberapa atlet Badminton ternama di dunia, yukk di simak!!</p>
			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
				<center>
						<!-- <a href="#" class="thumbnail">									 -->
						<img src="https://lh3.googleusercontent.com/We4MTdFB_dx2lfWi6NbRT71Ynr5oU2dCbl41bUNaEVg=w600-h415-no" alt="" class="img-rounded" height="200" width="230">
				</center>
				<h4><b>1. Taufik Hidayat (Indonesia)</b></h4>
				Taufik Hidayat merupakan anak bangsa yang lahir pada 10 Agustus 1981 di Bandung. Ia dijuluki sebagai pebulutangkis paling berbakat dalam sejarah.
				Taufik Hidayat juga tercatat sebagai legenda bulutangkis Indonesia dan dunia yang disebut fantastic four badminton. Kelebihannya yang sangat memukau termasuk backhand keras dan tepat, permainan net yang begitu cantik dan sulit dikembalikan lawan, smash silang dan keras serta drop shot apik ditambah mental juara menjadikan Taufik Hidayat meraih emas 6 kali berturut-turut di Indonesia Open dari tahun 1999 hingga 2006. 
			</div>
				
			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
				<center>
						<!-- <a href="#" class="thumbnail">									 -->
						<img src="https://lh3.googleusercontent.com/ubotUfGx2ZNJTiFqZNZ0tpP9OhRgMgaRbq7Tq3u-a9k=w620-h413-no" alt="" class="img-rounded" height="200:px" width="230:px">
				</center>	
				<h4><b>2. Lee Chong Wei (China)</b></h4>
				Lee Chong Wei digelari oleh Perdana Menteri Malaysia Najib Tun Razak sebagai pahlawan nasional, dan telah menerima gelar “Dato” atas kontribusinya dalam olahraga Malaysia. Lee Chong Wei memegang peringkat nomor 1 dunia untuk 199 minggu berturut-turut dari tanggal 21 Agustus 2008 sampai 14 Juni 2012. Dia adalah satu-satunya pemain bulutangkis Malaysia yang memegang posisi teratas di peringkat dunia lebih dari satu tahun. Otobiografinya “Berani menjadi Juara” secara resmi diterbitkan pada 18 Januari 2012.
			</div>
			<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
			<center>
						<!-- <a href="#" class="thumbnail">									 -->
						<img src="https://lh3.googleusercontent.com/CxHYnQS-lECT1-7mksfn8aMCzQhYKVrePFVxmU7uZ5M=w600-h399-no" alt="" class="img-rounded" height="200:px" width="230:px">
				</center>	
				<h4><b>3.Tony Gunawan (Indonesia) </b></h4>
				Pemain bulutangkis kelahiran Indonesia Tony Gunawan, dianggap oleh banyak orang sebagai salah satu atlet ganda terbaik dalam sejarah bulu tangkis internasional. Ia mewakili Indonesia diawal tahun 1992 sampai 2001 dan sekarang mewakili dan melatih atlet bulutangkis Amerika Serikat sejak tahun 2001. Dengan mitra ganda 3 orang yang berbeda, dia meraih medali emas Olimpiade Sydney tahun 2000, kejuaraan dunia (world Championship) 2001 Seville dan Kejuaraan Dunia Anaheim tahun 2005.
			</div>

				</div>
			</div>
			
		</nav>
		</div>
		

		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>