<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>About</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>

		<div class="container">	
		<nav class="navbar navbar-default" role="navigation">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
						<span class="sr-only"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
				</div>
		
					<div class="navbar-collapse-exl-collapse">
						<ul class="nav nav-tabs">
							  <li class="active" ><a href="<?php echo site_url()?>/home">Home</a></li>
							  <li><a href="<?php echo site_url()?>/about">About</a></li>
							  <li><a href="<?php echo site_url()?>/Contact">Contact</a></li>
						   <form class="navbar-form navbar-right" role="search">
						   <div class="form-group navbar-right">
										<input type="text" class="form-control" placeholder="Search">
									</div>
								<button type="submit" class="btn btn-default">Submit</button>
							</form>
						</ul>
						<div class="container">
								<!-- <a href="#" class="thumbnail">									 -->
								<img src="https://scontent.fcgk5-1.fna.fbcdn.net/v/t1.0-9/13775361_1621926611453430_3514831397816824042_n.jpg?_nc_eui2=v1%3AAeG-IP0c1dCevht8t4NDXVrC7Km90q_Wqu_0-B1y-bUMxzuY926J4XY_Mp4rGFrdy2TFZSyuYcDXqZnLnP-jtdEz5lAZUHNmh9wVdoy-oxRkXg&oh=bf3667c58a91f91885dd5b34525f5d3f&oe=5931AAB5" alt="" class="img-circle" height="100:px" width="100:px">
								<h3>Biodata</h3>
						</div>
						<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
								<img src="http://4.bp.blogspot.com/-9F6u6NKR66k/UYZHbz7qR0I/AAAAAAAAFa8/3HUTVV8NBuU/s1600/gambar+kartun+cantik+jilbab.jpg" alt="" height="100" width="150">
								<p>Nama			: Adita Mulya Sastri</p>
								<p>Nim			: 1541180145 </p>
								<p>Hobby		: Badminton</p>
								<p>Alamat 		: Jl.Jaya Srani II Blok 7D No.34, Sawojajar, Malang</p>
								<p>No Hp		: 082346820936</p>				
							</div>
							<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
								<img src="http://sumutpos.co/wp-content/uploads/2014/08/Sarjana-Ilustrasi.jpg" alt="" height="100" width="150">
								<p>Pendidikan		: Politeknik Negeri Malang</p>
								<p>Jurusan			: Teknologi Informasi</p>
								<p>Program Studi	: Teknik Informatika</p>
								<p>Semster			: 4 (Empat)</p>

							</div>	
							<div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
								<img src="https://inspiratorfreak.com/wp-content/uploads/2016/10/Untitled-1-1.jpg" alt="" height="100" width="150">
								<p>SD		: SDN 3 Langge (Class I-V)</p>
								<p>SD		: SDN 1 Langge (Class VI)</p>
								<p>SMP		: SMPN 1 Kaledupa (Class VII)</p>
								<p>SMP		: SMPN 2 Kaledupa (Class VIII-IX)</p>
								<p>SMA		: SMAN 2 Kaledupa (Class X-XII IPA)</p>

							</div>	
						</div>
						</div>
					</div>
				</div>	
			</div>
		</div>
	</nav>
</div>
		

		<!-- jQuery -->
		<!-- <script src="//code.jquery.com/jquery.js"></script> -->
		<!-- Bootstrap JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>